# Marginalia — portfolio template

Thanks for buying Marginalia! This is a complete, single-file portfolio website.
No build tools, no frameworks: open `index.html` in a browser and it works.

## 1. Preview it
Double-click `index.html`, or drag it into Chrome/Safari/Firefox.

## 2. Make it yours
Open `index.html` in any code editor (VS Code is free).

| What to change | Where to find it |
|---|---|
| Your name, page title, description | The `<title>` and `<meta name="description">` at the top, and the header/footer text |
| Projects and case studies | The JavaScript arrays near the bottom: **PROJECTS and QUOTES**. Each project is one object — copy one, edit the text, done. Case-study pages are generated from these automatically. |
| Colours | The `:root { … }` block at the top of the `<style>` tag (--paper, --ink, --hl-citron, --hl-sky). Change a value once, it updates everywhere. |
| Fonts | The Google Fonts `<link>` at the top (Gloock, Newsreader, IBM Plex Mono) and the `--f-…` font tokens in `:root`. |
| Email address | Search for `@` in the file and replace the sample address everywhere it appears. |
| Images | The template draws its covers in code so it works offline. To use screenshots, replace a cover's HTML with `<img src="your-image.jpg" alt="…">`. |

Tip: use your editor's search (Ctrl/Cmd + F) for any sample text you see on the page — that is exactly where to edit it.

## 3. Make the contact form send email
The form validates input but does not send anything until you connect it to a form service.
The easiest free option is [Formspree](https://formspree.io):
1. Create a form on Formspree and copy its endpoint (looks like `https://formspree.io/f/abcd1234`).
2. In `index.html`, find the form's `submit` handler and replace the success message code with:
   ```js
   fetch('https://formspree.io/f/abcd1234', { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } })
   ```
   (Give each input a `name` attribute so Formspree receives it.)

## 4. Put it online (free)
- **Netlify Drop:** go to https://app.netlify.com/drop and drag the folder containing `index.html`. You get a live URL in seconds.
- **GitHub Pages / Cloudflare Pages / Vercel** also work — it is just one static file.

## 5. Good to know
- Pages use hash links (`#work-your-project`), so every case study has its own shareable URL with no server setup.
- Animations respect the visitor's "reduce motion" setting automatically.
- Smooth scrolling uses the small Lenis library loaded from a CDN; if it fails to load, the site still scrolls normally.

Questions or a bug? Reply to your purchase email.
